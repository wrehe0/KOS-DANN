### [Вернуться на Главную](/README.md)

## Поддержка и тестирование программных модулей

### Лекции

[Средства разработки технической документации](/content/SupportAndtesting_of_software_modules/Documentation.md)

[Единая система программной документации (ЕСПД)](/content/SupportAndtesting_of_software_modules/ESPD.md)

[Автоматизация документирования кода](/content/SupportAndtesting_of_software_modules/AutoDocumentation.md)

[Основы проектирования баз данных](/content/Basics_database_design/README.md)

[Обеспечение качества функционирования компьютерных систем](/content/Ensuring_quality_computer_systems_functioning/README.md)

[]()

[]()

> Вместе со студентами показать как формируется навигация по репозиторию средствами Markdown!